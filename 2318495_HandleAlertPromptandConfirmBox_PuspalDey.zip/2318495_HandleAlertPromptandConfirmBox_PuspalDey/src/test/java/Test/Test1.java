package Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.net.SocketException;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
public class Test1 {
	public static void main(String[] args) {
		//1. Launching the Browser
		WebDriver driver = new ChromeDriver();
		
		//2. Opening the URL
		driver.get("https://demo.automationtesting.in/Alerts.html");
		//Applying the wait statement--
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		WebDriverWait mywait = new WebDriverWait(driver, Duration.ofSeconds(5));
		driver.manage().window().maximize();
		
		//3. Hovering the mouse over "SwitchTo" Menu
		WebElement ele = driver.findElement(By.xpath("//a[text() = 'SwitchTo']"));
		Actions action = new Actions(driver);
		action.moveToElement(ele).perform();
		
		//4. Clicking on Alerts 
		driver.findElement(By.xpath("//a[text() = 'Alerts']")).click();
		
		//5. Clicking on the link "Alert with Ok" and clicking on "Click the button to display an alert
		//   box"
		driver.findElement(By.xpath("//a[@class = 'analystic'][1]")).click();
		driver.findElement(By.xpath("//button[@class = 'btn btn-danger']")).click();
		
		//6. Checking is the alert message is coming or not, clicking on "Ok"
		Alert al1 = mywait.until(ExpectedConditions.alertIsPresent());
		al1.accept();
		
		//7. Clicking on "Alert with Ok and Cancel" at the left menu
		driver.findElement(By.xpath("//a[text() = 'Alert with OK & Cancel ']")).click();
		
		//8. Clicking the link "click the button to display a confirm box".
		driver.findElement(By.xpath("//button[@class = 'btn btn-primary']")).click();
		
		//9. Checking if the alert box is coming or not and then clicking on cancel and checking the
		//   text displayed
		Alert al2 = driver.switchTo().alert();
		al2.dismiss();
		driver.findElement(By.xpath("//p[@id = 'demo']")).getText(); // Reading the message displayed
		
		//10. Clicking on link "Alert with Textbox"
		driver.findElement(By.xpath("//a[text() = 'Alert with Textbox ']")).click();
		
		//11. Clicking the link "click the button to demonstrate the prompt box".
		driver.findElement(By.xpath("//button[@class = 'btn btn-info']")).click();
		
		//12. Checking if the alert box is appearing or not and sending my name and clicking on Ok
		Alert al3 = driver.switchTo().alert();
		String name = "Puspal Dey";
		al3.sendKeys(name);
		al3.accept();
		
		//13. Checking if the message "Hello Puspal Dey How are you today” is displayed
		String message = driver.findElement(By.xpath("//p[@id = 'demo1']")).getText();
		System.out.println(message);
		
		//14. Closing the browser
		driver.quit();
	}
}
